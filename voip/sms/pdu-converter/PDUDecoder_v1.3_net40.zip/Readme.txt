
===============================
Readme file for PDU Decoder 1.3
===============================


Contents of this file
=====================

1) About this tool
2) Requirements
3) History


1) About this tool
==================

PDU Decoder decodes an SMS PDU string into readable information.

It does not decode each and every type of message but for all other cases it is very helpful at finding out what's inside at all.

Available on the web at: http://www.scampers.org/steve/sms/

Author: Stefan Mayr


2) Requirements
===============

* .NET Framework 4.0


3) History
==========

Version 1.3:
* Adapted to latest GSMComm version 1.20.
* Fixed a bug that alphanumeric sender addresses can't be decoded.
* Messages with Unicode text and a user data header are now decoded properly.
* When decoding a user data or user data header, now also the length unit is shown.
  The length unit depends on the data coding, and may either be characters (septets) or
  bytes (octets).
* Fixed wrong decoding of the "More Messages To Send" flag in received SMS messages
  (SMS-DELIVER and SMS-STATUS-REPORT message types).

Version 1.2:
* Adapted to latest GSMComm version 1.15.
* Removed the "Decode" button, any available data is now decoded automatically.
* Added buttons to load encoded data from a file and save the output. Loading the data is also possible with drag-and-drop.

Version 1.1:
* Fixed a bug decoding SMS submits, delivers and status reports with invalid address lengths.

Version 1.0:
* initial release
